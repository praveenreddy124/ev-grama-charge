import React, { useState } from 'react';
import { Map, Calendar, Calculator, User, Zap } from 'lucide-react';
import { Tab, Host } from './types';
import { MOCK_HOSTS } from './services/data';
import MapPage from './pages/MapPage';
import BookingPage from './pages/BookingPage';
import CalculatorPage from './pages/CalculatorPage';
import HostPage from './pages/HostPage';

export default function App() {
  const [tab, setTab] = useState<Tab>('map');
  const [hosts, setHosts] = useState<Host[]>(MOCK_HOSTS);
  const [bookingHost, setBookingHost] = useState<Host | null>(null);

  const handleBook = (host: Host) => {
    setBookingHost(host);
    setTab('booking');
  };

  const NAV = [
    { id: 'map' as Tab, icon: <Map size={22} />, label: 'Map' },
    { id: 'booking' as Tab, icon: <Calendar size={22} />, label: 'Book' },
    { id: 'calculator' as Tab, icon: <Calculator size={22} />, label: 'Range' },
    { id: 'host' as Tab, icon: <User size={22} />, label: 'Host' },
  ];

  return (
    <div style={{
      maxWidth: 420,
      margin: '0 auto',
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--dark-bg)',
      position: 'relative',
    }}>
      {/* Header */}
      <header style={{
        padding: '14px 16px 10px',
        background: 'rgba(10,14,26,0.95)',
        backdropFilter: 'blur(10px)',
        borderBottom: '1px solid rgba(0,212,255,0.12)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexShrink: 0,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{
            width: 34, height: 34, borderRadius: 10,
            background: 'linear-gradient(135deg, rgba(0,212,255,0.3), rgba(0,53,102,0.5))',
            border: '1px solid rgba(0,212,255,0.4)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 0 12px rgba(0,212,255,0.2)',
          }}>
            <Zap size={18} color="var(--electric-blue)" fill="var(--electric-blue)" />
          </div>
          <div>
            <h1 style={{
              fontFamily: 'var(--font-display)',
              fontSize: 20, fontWeight: 700,
              letterSpacing: 1.5,
              background: 'linear-gradient(90deg, var(--electric-blue), var(--electric-green))',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}>
              EV-GRAMA CHARGE
            </h1>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{
            fontSize: 11, fontWeight: 600, padding: '3px 10px', borderRadius: 20,
            background: 'rgba(0,255,136,0.12)',
            border: '1px solid rgba(0,255,136,0.3)',
            color: 'var(--electric-green)',
            display: 'flex', alignItems: 'center', gap: 4,
          }}>
            <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--electric-green)', animation: 'blink-dot 2s infinite', display: 'inline-block' }} />
            {hosts.filter(h => h.isAvailable).length} Active
          </span>
        </div>
      </header>

      {/* Page Content */}
      <div style={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
        {tab === 'map' && <div style={{ height: '100%', overflowY: 'auto' }}><MapPage hosts={hosts} onBook={handleBook} /></div>}
        {tab === 'booking' && <div style={{ height: '100%', overflowY: 'auto' }}><BookingPage hosts={hosts} preSelected={bookingHost} /></div>}
        {tab === 'calculator' && <div style={{ height: '100%', overflowY: 'auto' }}><CalculatorPage /></div>}
        {tab === 'host' && <div style={{ height: '100%', overflowY: 'auto' }}><HostPage /></div>}
      </div>

      {/* Bottom Navigation */}
      <nav style={{
        display: 'flex',
        justifyContent: 'space-around',
        padding: '10px 8px 16px',
        background: 'rgba(10,14,26,0.97)',
        backdropFilter: 'blur(10px)',
        borderTop: '1px solid rgba(0,212,255,0.1)',
        flexShrink: 0,
      }}>
        {NAV.map(item => (
          <button
            key={item.id}
            onClick={() => setTab(item.id)}
            style={{
              flex: 1,
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
              padding: '8px 4px',
              background: 'none', border: 'none',
              cursor: 'pointer',
              color: tab === item.id ? 'var(--electric-blue)' : 'var(--text-muted)',
              transition: 'all 0.2s',
              position: 'relative',
            }}
          >
            {tab === item.id && (
              <div style={{
                position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)',
                width: 32, height: 3, borderRadius: 2,
                background: 'var(--electric-blue)',
                boxShadow: '0 0 8px rgba(0,212,255,0.6)',
              }} />
            )}
            <div style={{
              padding: '6px 14px', borderRadius: 12,
              background: tab === item.id ? 'rgba(0,212,255,0.1)' : 'transparent',
              transition: 'all 0.2s',
            }}>
              {item.icon}
            </div>
            <span style={{ fontSize: 10, fontWeight: tab === item.id ? 600 : 400, letterSpacing: 0.3 }}>
              {item.label}
            </span>
          </button>
        ))}
      </nav>
    </div>
  );
}
