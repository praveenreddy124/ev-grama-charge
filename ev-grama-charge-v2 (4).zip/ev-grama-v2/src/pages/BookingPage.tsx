import React, { useState } from 'react';
import { Clock, Zap, CheckCircle, Calendar, User, Phone, ChevronDown } from 'lucide-react';
import { Host } from '../types';

interface Props {
  hosts: Host[];
  preSelected?: Host | null;
}

const TIME_SLOTS = [
  '08:00 AM', '09:00 AM', '10:00 AM', '11:00 AM',
  '12:00 PM', '01:00 PM', '02:00 PM', '03:00 PM',
  '04:00 PM', '05:00 PM', '06:00 PM', '07:00 PM',
];

export default function BookingPage({ hosts, preSelected }: Props) {
  const availableHosts = hosts.filter(h => h.isAvailable);
  const [selectedHost, setSelectedHost] = useState<Host | null>(preSelected || availableHosts[0] || null);
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [duration, setDuration] = useState(1);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [booked, setBooked] = useState(false);
  const [loading, setLoading] = useState(false);

  const cost = selectedHost ? selectedHost.pricePerHour * duration : 0;
  const kmsGained = selectedHost
    ? Math.round(selectedHost.powerKw * duration * (selectedHost.socketType === '15A' ? 45 : 28))
    : 0;

  const handleBook = () => {
    if (!selectedHost || !selectedSlot || !name) return;
    setLoading(true);
    setTimeout(() => { setLoading(false); setBooked(true); }, 1800);
  };

  if (booked) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', padding: 32, textAlign: 'center' }}>
        <div style={{
          width: 90, height: 90, borderRadius: '50%',
          background: 'rgba(0,255,136,0.1)',
          border: '2px solid var(--electric-green)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          marginBottom: 20,
          boxShadow: '0 0 40px rgba(0,255,136,0.3)',
          animation: 'glow-pulse 2s infinite',
        }}>
          <CheckCircle size={44} color="var(--electric-green)" />
        </div>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700, color: 'var(--electric-green)', letterSpacing: 1 }}>
          BOOKING CONFIRMED!
        </h2>
        <p style={{ color: 'var(--text-secondary)', marginTop: 8, fontSize: 14 }}>
          Slot reserved at {selectedHost?.shopName}
        </p>
        <div style={{
          marginTop: 24, width: '100%',
          background: 'var(--card-bg)',
          border: '1px solid rgba(0,255,136,0.2)',
          borderRadius: 16, padding: 20,
        }}>
          {[
            ['Host', selectedHost?.shopName],
            ['Time', selectedSlot],
            ['Duration', `${duration} hour(s)`],
            ['Cost', `₹${cost}`],
            ['Est. Range Added', `~${kmsGained} km`],
          ].map(([label, val]) => (
            <div key={label as string} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid rgba(0,212,255,0.08)' }}>
              <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>{label}</span>
              <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{val}</span>
            </div>
          ))}
        </div>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 16 }}>
          Show this confirmation to the host on arrival
        </p>
        <button
          onClick={() => { setBooked(false); setSelectedSlot(null); setName(''); setPhone(''); }}
          style={{
            marginTop: 20, padding: '12px 32px',
            background: 'rgba(0,212,255,0.1)',
            border: '1px solid rgba(0,212,255,0.3)',
            borderRadius: 12, color: 'var(--electric-blue)',
            fontSize: 14, fontWeight: 600, cursor: 'pointer',
          }}
        >
          Book Another Slot
        </button>
      </div>
    );
  }

  return (
    <div style={{ padding: '16px', overflowY: 'auto', height: '100%', display: 'flex', flexDirection: 'column', gap: 16 }}>
      <p style={{ fontSize: 12, color: 'var(--text-muted)', letterSpacing: 1 }}>RESERVE A CHARGING SLOT</p>

      {/* Host Selector */}
      <div>
        <p style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 8 }}>Select Host</p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {availableHosts.map(host => (
            <div
              key={host.id}
              onClick={() => setSelectedHost(host)}
              style={{
                padding: '12px 14px',
                borderRadius: 12,
                border: `1px solid ${selectedHost?.id === host.id ? 'var(--electric-blue)' : 'var(--card-border)'}`,
                background: selectedHost?.id === host.id ? 'rgba(0,212,255,0.08)' : 'var(--card-bg)',
                cursor: 'pointer',
                display: 'flex', alignItems: 'center', gap: 12,
                transition: 'all 0.2s',
              }}
            >
              <div style={{
                width: 36, height: 36, borderRadius: 10,
                background: 'rgba(0,255,136,0.1)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <Zap size={18} color="var(--electric-green)" />
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: 13, fontWeight: 600 }}>{host.shopName}</p>
                <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>{host.distanceKm}km · {host.socketType} · ₹{host.pricePerHour}/hr</p>
              </div>
              <div style={{
                width: 18, height: 18, borderRadius: '50%',
                border: `2px solid ${selectedHost?.id === host.id ? 'var(--electric-blue)' : 'var(--text-muted)'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {selectedHost?.id === host.id && (
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--electric-blue)' }} />
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Duration */}
      <div>
        <p style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 8 }}>Duration (hours)</p>
        <div style={{ display: 'flex', gap: 8 }}>
          {[1, 2, 3].map(d => (
            <button
              key={d}
              onClick={() => setDuration(d)}
              style={{
                flex: 1, padding: '10px',
                borderRadius: 10,
                border: `1px solid ${duration === d ? 'var(--electric-blue)' : 'var(--card-border)'}`,
                background: duration === d ? 'rgba(0,212,255,0.12)' : 'var(--card-bg)',
                color: duration === d ? 'var(--electric-blue)' : 'var(--text-secondary)',
                fontSize: 14, fontWeight: 600, cursor: 'pointer',
                transition: 'all 0.2s',
              }}
            >
              {d}h
            </button>
          ))}
        </div>
      </div>

      {/* Cost preview */}
      {selectedHost && (
        <div style={{
          background: 'linear-gradient(135deg, rgba(0,212,255,0.08), rgba(0,53,102,0.3))',
          border: '1px solid rgba(0,212,255,0.2)',
          borderRadius: 14, padding: '14px 16px',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <div>
            <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>Estimated Cost</p>
            <p style={{ fontSize: 24, fontWeight: 700, color: 'var(--electric-blue)', fontFamily: 'var(--font-display)' }}>₹{cost}</p>
          </div>
          <div style={{ textAlign: 'right' }}>
            <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>Range Added</p>
            <p style={{ fontSize: 24, fontWeight: 700, color: 'var(--electric-green)', fontFamily: 'var(--font-display)' }}>~{kmsGained} km</p>
          </div>
        </div>
      )}

      {/* Time Slots */}
      <div>
        <p style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 8 }}>Pick a Time Slot</p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
          {TIME_SLOTS.map(slot => (
            <button
              key={slot}
              onClick={() => setSelectedSlot(slot)}
              style={{
                padding: '8px 4px',
                borderRadius: 10,
                border: `1px solid ${selectedSlot === slot ? 'var(--electric-blue)' : 'var(--card-border)'}`,
                background: selectedSlot === slot ? 'rgba(0,212,255,0.12)' : 'var(--card-bg)',
                color: selectedSlot === slot ? 'var(--electric-blue)' : 'var(--text-secondary)',
                fontSize: 12, fontWeight: 500, cursor: 'pointer',
                transition: 'all 0.15s',
              }}
            >
              {slot}
            </button>
          ))}
        </div>
      </div>

      {/* User Details */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <p style={{ fontSize: 12, color: 'var(--text-secondary)' }}>Your Details</p>
        <div style={{ position: 'relative' }}>
          <User size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          <input
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="Your Name"
            style={{
              width: '100%', padding: '11px 12px 11px 34px',
              background: 'var(--card-bg)', border: '1px solid var(--card-border)',
              borderRadius: 10, color: 'var(--text-primary)', fontSize: 14,
              outline: 'none',
            }}
          />
        </div>
        <div style={{ position: 'relative' }}>
          <Phone size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          <input
            value={phone}
            onChange={e => setPhone(e.target.value)}
            placeholder="Phone Number"
            style={{
              width: '100%', padding: '11px 12px 11px 34px',
              background: 'var(--card-bg)', border: '1px solid var(--card-border)',
              borderRadius: 10, color: 'var(--text-primary)', fontSize: 14,
              outline: 'none',
            }}
          />
        </div>
      </div>

      {/* Book Button */}
      <button
        onClick={handleBook}
        disabled={!selectedHost || !selectedSlot || !name || loading}
        style={{
          width: '100%', padding: '15px',
          borderRadius: 14, border: 'none',
          background: (!selectedHost || !selectedSlot || !name)
            ? 'rgba(0,212,255,0.1)'
            : 'linear-gradient(135deg, #00d4ff, #0058bc)',
          color: (!selectedHost || !selectedSlot || !name) ? 'var(--text-muted)' : 'white',
          fontSize: 15, fontWeight: 700,
          cursor: (!selectedHost || !selectedSlot || !name) ? 'not-allowed' : 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          boxShadow: (!selectedHost || !selectedSlot || !name) ? 'none' : '0 4px 20px rgba(0,212,255,0.35)',
          transition: 'all 0.2s',
        }}
      >
        {loading ? (
          <div style={{ width: 20, height: 20, border: '2px solid rgba(255,255,255,0.3)', borderTop: '2px solid white', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
        ) : (
          <><Clock size={16} /> Confirm Booking</>
        )}
      </button>
    </div>
  );
}
