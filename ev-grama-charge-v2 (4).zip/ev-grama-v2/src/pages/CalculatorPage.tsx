import React, { useState, useEffect } from 'react';
import { Zap, TrendingUp, Clock, Battery } from 'lucide-react';
import { EV_MODELS } from '../services/data';

export default function CalculatorPage() {
  const [modelIdx, setModelIdx] = useState(0);
  const [minutes, setMinutes] = useState(30);
  const [socketType, setSocketType] = useState<'5A' | '15A'>('15A');
  const [animating, setAnimating] = useState(false);
  const [showResult, setShowResult] = useState(false);

  const model = EV_MODELS[modelIdx];
  const powerKw = socketType === '15A' ? 1.5 : 0.75;
  const hoursCharged = minutes / 60;
  const kwhAdded = powerKw * hoursCharged;
  const percentAdded = Math.min(100, Math.round((kwhAdded / model.batteryKwh) * 100));
  const kmsGained = Math.round((kwhAdded / model.batteryKwh) * model.rangeKm);
  const cost15A = Math.round((minutes / 60) * 40);
  const cost5A = Math.round((minutes / 60) * 22);
  const cost = socketType === '15A' ? cost15A : cost5A;

  const handleCalculate = () => {
    setAnimating(true);
    setShowResult(false);
    setTimeout(() => { setAnimating(false); setShowResult(true); }, 1200);
  };

  useEffect(() => { setShowResult(false); }, [modelIdx, minutes, socketType]);

  const fillBars = Math.round(percentAdded / 10);

  return (
    <div style={{ padding: '16px', overflowY: 'auto', height: '100%', display: 'flex', flexDirection: 'column', gap: 18 }}>
      <p style={{ fontSize: 12, color: 'var(--text-muted)', letterSpacing: 1 }}>CHARGING CALCULATOR</p>

      {/* Battery Animation */}
      <div style={{ display: 'flex', justifyContent: 'center', padding: '10px 0' }}>
        <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          {/* Battery body */}
          <svg width="160" height="80" viewBox="0 0 160 80">
            <rect x="4" y="8" width="140" height="64" rx="10" fill="none" stroke="rgba(0,212,255,0.4)" strokeWidth="2.5"/>
            <rect x="144" y="28" width="12" height="24" rx="4" fill="rgba(0,212,255,0.3)"/>
            {/* Fill segments */}
            {[0,1,2,3,4,5,6,7,8,9].map(i => (
              <rect
                key={i}
                x={14 + i * 13}
                y={16}
                width={10}
                height={48}
                rx={3}
                fill={i < fillBars
                  ? (fillBars <= 3 ? 'var(--danger)' : fillBars <= 6 ? 'var(--warning)' : 'var(--electric-green)')
                  : 'rgba(255,255,255,0.05)'
                }
                style={{
                  transition: `fill 0.3s ${i * 0.05}s, opacity 0.3s`,
                  opacity: animating && i < fillBars ? (Math.sin(Date.now() / 300 + i) * 0.3 + 0.7) : 1,
                }}
              />
            ))}
            {/* Lightning bolt overlay */}
            {animating && (
              <text x="75" y="52" textAnchor="middle" fontSize="28" fill="white" opacity="0.9" style={{ animation: 'blink-dot 0.4s infinite' }}>⚡</text>
            )}
          </svg>
          <div style={{ position: 'absolute', bottom: -8, fontSize: 13, fontWeight: 700, color: percentAdded > 60 ? 'var(--electric-green)' : percentAdded > 30 ? 'var(--warning)' : 'var(--danger)' }}>
            +{percentAdded}% charged
          </div>
        </div>
      </div>

      {/* EV Model Selector */}
      <div>
        <p style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 8 }}>Your EV Model</p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {EV_MODELS.map((m, i) => (
            <button
              key={m.name}
              onClick={() => setModelIdx(i)}
              style={{
                padding: '10px 14px',
                borderRadius: 10,
                border: `1px solid ${modelIdx === i ? 'var(--electric-blue)' : 'var(--card-border)'}`,
                background: modelIdx === i ? 'rgba(0,212,255,0.08)' : 'var(--card-bg)',
                color: modelIdx === i ? 'var(--electric-blue)' : 'var(--text-secondary)',
                fontSize: 13, fontWeight: 500,
                cursor: 'pointer', textAlign: 'left',
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                transition: 'all 0.15s',
              }}
            >
              <span>{m.name}</span>
              <span style={{ fontSize: 12, opacity: 0.7 }}>{m.batteryKwh} kWh · {m.rangeKm} km</span>
            </button>
          ))}
        </div>
      </div>

      {/* Socket Type */}
      <div>
        <p style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 8 }}>Socket Type</p>
        <div style={{ display: 'flex', gap: 10 }}>
          {(['5A', '15A'] as const).map(s => (
            <button
              key={s}
              onClick={() => setSocketType(s)}
              style={{
                flex: 1, padding: '12px',
                borderRadius: 12,
                border: `1px solid ${socketType === s ? (s === '15A' ? 'var(--electric-green)' : 'var(--warning)') : 'var(--card-border)'}`,
                background: socketType === s
                  ? (s === '15A' ? 'rgba(0,255,136,0.08)' : 'rgba(255,184,0,0.08)')
                  : 'var(--card-bg)',
                color: socketType === s ? (s === '15A' ? 'var(--electric-green)' : 'var(--warning)') : 'var(--text-secondary)',
                cursor: 'pointer', transition: 'all 0.2s',
              }}
            >
              <div style={{ fontSize: 16, fontWeight: 700, fontFamily: 'var(--font-display)' }}>{s}</div>
              <div style={{ fontSize: 11, marginTop: 2, opacity: 0.8 }}>
                {s === '15A' ? '1.5kW Fast' : '0.75kW Slow'}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Duration Slider */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
          <p style={{ fontSize: 12, color: 'var(--text-secondary)' }}>Charging Duration</p>
          <p style={{ fontSize: 14, fontWeight: 700, color: 'var(--electric-blue)' }}>{minutes} min</p>
        </div>
        <input
          type="range" min={10} max={120} step={5}
          value={minutes}
          onChange={e => setMinutes(Number(e.target.value))}
          style={{
            width: '100%', height: 4, cursor: 'pointer',
            accentColor: 'var(--electric-blue)',
          }}
        />
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
          <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>10 min</span>
          <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>2 hours</span>
        </div>
      </div>

      {/* Calculate Button */}
      <button
        onClick={handleCalculate}
        style={{
          width: '100%', padding: '14px',
          borderRadius: 14, border: 'none',
          background: 'linear-gradient(135deg, var(--electric-green), #00a855)',
          color: '#0a1a0f',
          fontSize: 15, fontWeight: 700,
          cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          boxShadow: '0 4px 20px rgba(0,255,136,0.3)',
        }}
      >
        {animating ? (
          <div style={{ width: 18, height: 18, border: '2px solid rgba(0,0,0,0.2)', borderTop: '2px solid #0a1a0f', borderRadius: '50%', animation: 'spin 0.7s linear infinite' }} />
        ) : (
          <><Zap size={16} fill="currentColor" /> Calculate Range</>
        )}
      </button>

      {/* Results */}
      {showResult && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, animation: 'fadeIn 0.4s ease' }}>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', letterSpacing: 1 }}>RESULTS</p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {[
              { icon: <TrendingUp size={20} color="var(--electric-green)" />, label: 'Range Added', value: `${kmsGained} km`, color: 'var(--electric-green)' },
              { icon: <Battery size={20} color="var(--electric-blue)" />, label: 'Battery Added', value: `${percentAdded}%`, color: 'var(--electric-blue)' },
              { icon: <Zap size={20} color="var(--warning)" />, label: 'Energy Added', value: `${kwhAdded.toFixed(2)} kWh`, color: 'var(--warning)' },
              { icon: <Clock size={20} color="var(--text-secondary)" />, label: 'Est. Cost', value: `₹${cost}`, color: 'var(--text-primary)' },
            ].map(item => (
              <div key={item.label} style={{
                background: 'var(--card-bg)',
                border: '1px solid var(--card-border)',
                borderRadius: 14, padding: '14px',
                display: 'flex', flexDirection: 'column', gap: 6,
              }}>
                {item.icon}
                <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>{item.label}</p>
                <p style={{ fontSize: 22, fontWeight: 700, fontFamily: 'var(--font-display)', color: item.color }}>{item.value}</p>
              </div>
            ))}
          </div>
          <div style={{
            background: 'rgba(0,212,255,0.05)',
            border: '1px solid rgba(0,212,255,0.15)',
            borderRadius: 12, padding: '12px 14px',
          }}>
            <p style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.6 }}>
              ⚡ With a <strong style={{ color: 'var(--electric-blue)' }}>{minutes}-minute</strong> charge using a <strong style={{ color: 'var(--electric-blue)' }}>{socketType} socket</strong>, your <strong style={{ color: 'var(--electric-green)' }}>{model.name}</strong> can travel approximately <strong style={{ color: 'var(--electric-green)' }}>{kmsGained} km</strong> more.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
