import React, { useState } from 'react';
import { Zap, TrendingUp, Star, ToggleLeft, ToggleRight, IndianRupee, Users, Settings } from 'lucide-react';

interface Booking {
  customer: string;
  time: string;
  units: string;
  amount: number;
  date: string;
}

const RECENT: Booking[] = [
  { customer: 'Ravi K.', time: '10:30 AM', units: '1.5 kWh', amount: 40, date: 'Today' },
  { customer: 'Meena S.', time: '04:15 PM', units: '3.0 kWh', amount: 80, date: 'Yesterday' },
  { customer: 'Anwar A.', time: '11:20 AM', units: '1.5 kWh', amount: 40, date: 'Yesterday' },
  { customer: 'Priya L.', time: '02:00 PM', units: '3.0 kWh', amount: 80, date: 'Mon' },
  { customer: 'Suresh R.', time: '09:00 AM', units: '1.5 kWh', amount: 40, date: 'Sun' },
];

export default function HostPage() {
  const [isAvailable, setIsAvailable] = useState(true);
  const [pricePerHour, setPricePerHour] = useState(40);
  const [socketType, setSocketType] = useState<'5A' | '15A'>('15A');
  const [showSettings, setShowSettings] = useState(false);
  const [toggling, setToggling] = useState(false);

  const totalEarnings = 1240;
  const thisMonth = 320;
  const totalCharges = 142;
  const rating = 4.8;

  const handleToggle = () => {
    setToggling(true);
    setTimeout(() => { setIsAvailable(p => !p); setToggling(false); }, 400);
  };

  return (
    <div style={{ padding: '16px', overflowY: 'auto', height: '100%', display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', letterSpacing: 1 }}>HOST DASHBOARD</p>
        <button
          onClick={() => setShowSettings(p => !p)}
          style={{ background: 'rgba(0,212,255,0.1)', border: '1px solid rgba(0,212,255,0.2)', borderRadius: 8, padding: '6px 10px', color: 'var(--electric-blue)', display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, cursor: 'pointer' }}
        >
          <Settings size={13} /> Settings
        </button>
      </div>

      {/* Host Profile Card */}
      <div style={{
        background: 'linear-gradient(135deg, rgba(0,53,102,0.6), rgba(0,29,61,0.8))',
        border: '1px solid rgba(0,212,255,0.25)',
        borderRadius: 18, padding: 20,
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', top: -20, right: -20, width: 100, height: 100, borderRadius: '50%', background: 'rgba(0,212,255,0.05)', border: '1px solid rgba(0,212,255,0.1)' }} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 16 }}>
          <div style={{
            width: 52, height: 52, borderRadius: 14,
            background: 'linear-gradient(135deg, rgba(0,212,255,0.2), rgba(0,53,102,0.5))',
            border: '2px solid rgba(0,212,255,0.3)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 22,
          }}>🏪</div>
          <div>
            <p style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 700, letterSpacing: 0.5 }}>Ravi General Store</p>
            <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>Main Bazaar Road, Grama Hub</p>
          </div>
        </div>

        {/* Availability Toggle */}
        <div style={{
          background: 'rgba(0,0,0,0.3)',
          borderRadius: 14, padding: '14px 16px',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          border: `1px solid ${isAvailable ? 'rgba(0,255,136,0.25)' : 'rgba(255,69,96,0.25)'}`,
          transition: 'border-color 0.3s',
        }}>
          <div>
            <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>STATION STATUS</p>
            <p style={{
              fontSize: 17, fontWeight: 700,
              color: isAvailable ? 'var(--electric-green)' : 'var(--danger)',
              fontFamily: 'var(--font-display)', letterSpacing: 0.5,
              transition: 'color 0.3s',
              display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <span style={{
                width: 8, height: 8, borderRadius: '50%',
                background: isAvailable ? 'var(--electric-green)' : 'var(--danger)',
                animation: isAvailable ? 'blink-dot 1.5s infinite' : 'none',
                display: 'inline-block',
              }} />
              {toggling ? 'Updating...' : isAvailable ? 'OPEN FOR CHARGING' : 'CLOSED / BUSY'}
            </p>
          </div>
          <button
            onClick={handleToggle}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              color: isAvailable ? 'var(--electric-green)' : 'var(--danger)',
              transition: 'all 0.3s', transform: toggling ? 'scale(0.9)' : 'scale(1)',
            }}
          >
            {isAvailable
              ? <ToggleRight size={48} />
              : <ToggleLeft size={48} />
            }
          </button>
        </div>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <div style={{
          background: 'var(--card-bg)',
          border: '1px solid var(--card-border)',
          borderRadius: 16, padding: 16,
          display: 'flex', flexDirection: 'column', gap: 14,
          animation: 'fadeIn 0.2s ease',
        }}>
          <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>Socket Settings</p>
          <div>
            <p style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 8 }}>Socket Type</p>
            <div style={{ display: 'flex', gap: 8 }}>
              {(['5A', '15A'] as const).map(s => (
                <button key={s} onClick={() => setSocketType(s)} style={{
                  flex: 1, padding: 10, borderRadius: 10,
                  border: `1px solid ${socketType === s ? 'var(--electric-blue)' : 'var(--card-border)'}`,
                  background: socketType === s ? 'rgba(0,212,255,0.1)' : 'transparent',
                  color: socketType === s ? 'var(--electric-blue)' : 'var(--text-secondary)',
                  fontSize: 13, fontWeight: 600, cursor: 'pointer',
                }}>
                  {s}
                </button>
              ))}
            </div>
          </div>
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <p style={{ fontSize: 12, color: 'var(--text-secondary)' }}>Price per Hour</p>
              <p style={{ fontSize: 14, fontWeight: 700, color: 'var(--electric-green)' }}>₹{pricePerHour}</p>
            </div>
            <input type="range" min={10} max={100} step={5} value={pricePerHour}
              onChange={e => setPricePerHour(Number(e.target.value))}
              style={{ width: '100%', accentColor: 'var(--electric-green)' }} />
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
              <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>₹10/hr</span>
              <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>₹100/hr</span>
            </div>
          </div>
        </div>
      )}

      {/* Stats Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {[
          { icon: <IndianRupee size={18} color="var(--electric-green)" />, label: 'Total Earned', value: `₹${totalEarnings.toLocaleString()}`, color: 'var(--electric-green)' },
          { icon: <TrendingUp size={18} color="var(--electric-blue)" />, label: 'This Month', value: `₹${thisMonth}`, color: 'var(--electric-blue)' },
          { icon: <Zap size={18} color="var(--warning)" />, label: 'Total Charges', value: totalCharges, color: 'var(--warning)' },
          { icon: <Star size={18} color="#ffb800" fill="#ffb800" />, label: 'Rating', value: rating, color: '#ffb800' },
        ].map(item => (
          <div key={item.label} style={{
            background: 'var(--card-bg)',
            border: '1px solid var(--card-border)',
            borderRadius: 14, padding: '14px',
          }}>
            {item.icon}
            <p style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 8 }}>{item.label}</p>
            <p style={{ fontSize: 22, fontWeight: 700, fontFamily: 'var(--font-display)', color: item.color, marginTop: 2 }}>{item.value}</p>
          </div>
        ))}
      </div>

      {/* Recent Bookings */}
      <div>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 10, letterSpacing: 1 }}>RECENT BOOKINGS</p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {RECENT.map((b, i) => (
            <div key={i} style={{
              background: 'var(--card-bg)',
              border: '1px solid var(--card-border)',
              borderRadius: 12, padding: '12px 14px',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{
                  width: 34, height: 34, borderRadius: '50%',
                  background: 'rgba(0,212,255,0.1)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 14,
                }}>👤</div>
                <div>
                  <p style={{ fontSize: 13, fontWeight: 600 }}>{b.customer}</p>
                  <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>{b.date} · {b.time} · {b.units}</p>
                </div>
              </div>
              <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--electric-green)', fontFamily: 'var(--font-display)' }}>
                +₹{b.amount}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
