import React, { useState } from 'react';
import { MapPin, Navigation, Zap, Star, Clock, ChevronRight, X } from 'lucide-react';
import { Host } from '../types';

interface Props {
  hosts: Host[];
  onBook: (host: Host) => void;
}

export default function MapPage({ hosts, onBook }: Props) {
  const [selected, setSelected] = useState<Host | null>(null);
  const [filter, setFilter] = useState<'all' | 'available'>('all');

  const filtered = filter === 'available' ? hosts.filter(h => h.isAvailable) : hosts;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Filter Bar */}
      <div style={{ padding: '12px 16px', display: 'flex', gap: 8 }}>
        {(['all', 'available'] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            style={{
              padding: '6px 16px',
              borderRadius: 20,
              border: `1px solid ${filter === f ? 'var(--electric-blue)' : 'rgba(0,212,255,0.2)'}`,
              background: filter === f ? 'rgba(0,212,255,0.15)' : 'transparent',
              color: filter === f ? 'var(--electric-blue)' : 'var(--text-secondary)',
              fontSize: 13,
              fontWeight: 500,
              cursor: 'pointer',
              transition: 'all 0.2s',
            }}
          >
            {f === 'all' ? 'All Points' : '⚡ Available Now'}
          </button>
        ))}
        <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--text-muted)', alignSelf: 'center' }}>
          {filtered.length} found
        </span>
      </div>

      {/* Simulated Map */}
      <div style={{
        margin: '0 16px',
        height: 220,
        background: 'linear-gradient(135deg, #0a1628 0%, #0d2040 50%, #0a1628 100%)',
        borderRadius: 16,
        border: '1px solid rgba(0,212,255,0.2)',
        position: 'relative',
        overflow: 'hidden',
      }}>
        {/* Grid lines */}
        <svg width="100%" height="100%" style={{ position: 'absolute', inset: 0 }}>
          <defs>
            <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
              <path d="M 30 0 L 0 0 0 30" fill="none" stroke="rgba(0,212,255,0.07)" strokeWidth="0.5"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
          {/* Roads */}
          <line x1="0" y1="110" x2="100%" y2="110" stroke="rgba(0,212,255,0.15)" strokeWidth="2"/>
          <line x1="160" y1="0" x2="160" y2="100%" stroke="rgba(0,212,255,0.15)" strokeWidth="2"/>
          <line x1="0" y1="60" x2="100%" y2="160" stroke="rgba(0,212,255,0.08)" strokeWidth="1.5"/>
        </svg>

        {/* Host pins */}
        {filtered.map((host, i) => {
          const positions = [
            { left: '30%', top: '45%' }, { left: '55%', top: '30%' },
            { left: '20%', top: '65%' }, { left: '70%', top: '55%' },
            { left: '45%', top: '70%' },
          ];
          const pos = positions[i % positions.length];
          return (
            <div
              key={host.id}
              onClick={() => setSelected(host)}
              style={{
                position: 'absolute',
                left: pos.left, top: pos.top,
                transform: 'translate(-50%, -50%)',
                cursor: 'pointer',
                zIndex: selected?.id === host.id ? 10 : 1,
              }}
            >
              {host.isAvailable && (
                <div style={{
                  position: 'absolute', inset: -4,
                  borderRadius: '50%',
                  border: '2px solid var(--electric-green)',
                  animation: 'pulse-ring 2s infinite',
                  opacity: 0.6,
                }} />
              )}
              <div style={{
                width: 36, height: 36, borderRadius: '50%',
                background: host.isAvailable ? 'var(--electric-green)' : 'var(--danger)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                border: `2px solid ${selected?.id === host.id ? 'white' : 'transparent'}`,
                boxShadow: host.isAvailable
                  ? '0 0 12px rgba(0,255,136,0.5)'
                  : '0 0 8px rgba(255,69,96,0.4)',
                transition: 'all 0.2s',
              }}>
                <Zap size={16} color="#0a0e1a" fill="#0a0e1a" />
              </div>
              <div style={{
                position: 'absolute', top: '100%', left: '50%',
                transform: 'translateX(-50%)',
                marginTop: 4,
                background: 'rgba(10,14,26,0.9)',
                border: '1px solid rgba(0,212,255,0.3)',
                borderRadius: 6,
                padding: '2px 6px',
                fontSize: 10,
                whiteSpace: 'nowrap',
                color: 'var(--text-primary)',
              }}>
                {host.distanceKm}km
              </div>
            </div>
          );
        })}

        {/* User location */}
        <div style={{
          position: 'absolute', left: '48%', top: '48%',
          transform: 'translate(-50%,-50%)',
          width: 14, height: 14, borderRadius: '50%',
          background: 'var(--electric-blue)',
          boxShadow: '0 0 0 4px rgba(0,212,255,0.2)',
          zIndex: 5,
        }} />

        {/* Legend */}
        <div style={{
          position: 'absolute', bottom: 10, right: 10,
          display: 'flex', flexDirection: 'column', gap: 4,
          background: 'rgba(10,14,26,0.85)',
          border: '1px solid rgba(0,212,255,0.15)',
          borderRadius: 8, padding: '6px 10px',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 10, color: 'var(--text-secondary)' }}>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--electric-green)' }} /> Available
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 10, color: 'var(--text-secondary)' }}>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--danger)' }} /> Busy
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 10, color: 'var(--text-secondary)' }}>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--electric-blue)' }} /> You
          </div>
        </div>
      </div>

      {/* Host Cards */}
      <div style={{ padding: '12px 16px', flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 2 }}>NEARBY CHARGING POINTS</p>
        {filtered.map(host => (
          <div
            key={host.id}
            onClick={() => setSelected(host)}
            style={{
              background: selected?.id === host.id ? 'rgba(0,212,255,0.08)' : 'var(--card-bg)',
              border: `1px solid ${selected?.id === host.id ? 'rgba(0,212,255,0.4)' : 'var(--card-border)'}`,
              borderRadius: 14,
              padding: '12px 14px',
              cursor: 'pointer',
              transition: 'all 0.2s',
              animation: 'fadeIn 0.3s ease both',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{
                  width: 42, height: 42, borderRadius: 12,
                  background: host.isAvailable ? 'rgba(0,255,136,0.1)' : 'rgba(255,69,96,0.1)',
                  border: `1px solid ${host.isAvailable ? 'rgba(0,255,136,0.3)' : 'rgba(255,69,96,0.3)'}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <Zap size={20} color={host.isAvailable ? 'var(--electric-green)' : 'var(--danger)'} />
                </div>
                <div>
                  <p style={{ fontWeight: 600, fontSize: 14, color: 'var(--text-primary)' }}>{host.shopName}</p>
                  <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{host.address}</p>
                </div>
              </div>
              <ChevronRight size={16} color="var(--text-muted)" />
            </div>
            <div style={{ display: 'flex', gap: 12, marginTop: 10, flexWrap: 'wrap' }}>
              <span style={{ fontSize: 12, color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: 3 }}>
                <Navigation size={11} /> {host.distanceKm} km
              </span>
              <span style={{ fontSize: 12, color: 'var(--electric-blue)', display: 'flex', alignItems: 'center', gap: 3 }}>
                <Zap size={11} /> {host.socketType} · {host.powerKw}kW
              </span>
              <span style={{ fontSize: 12, color: 'var(--warning)', display: 'flex', alignItems: 'center', gap: 3 }}>
                <Star size={11} fill="var(--warning)" /> {host.rating}
              </span>
              <span style={{ fontSize: 12, color: 'var(--electric-green)', fontWeight: 600 }}>
                ₹{host.pricePerHour}/hr
              </span>
              <span style={{
                marginLeft: 'auto',
                fontSize: 11, fontWeight: 600,
                padding: '2px 8px', borderRadius: 20,
                background: host.isAvailable ? 'rgba(0,255,136,0.15)' : 'rgba(255,69,96,0.15)',
                color: host.isAvailable ? 'var(--electric-green)' : 'var(--danger)',
                display: 'flex', alignItems: 'center', gap: 3,
              }}>
                <span style={{
                  width: 5, height: 5, borderRadius: '50%',
                  background: host.isAvailable ? 'var(--electric-green)' : 'var(--danger)',
                  animation: host.isAvailable ? 'blink-dot 1.5s infinite' : 'none',
                  display: 'inline-block',
                }} />
                {host.isAvailable ? 'Available' : 'Busy'}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Detail Drawer */}
      {selected && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 50,
          background: 'rgba(0,0,0,0.7)',
          display: 'flex', alignItems: 'flex-end',
        }} onClick={() => setSelected(null)}>
          <div
            onClick={e => e.stopPropagation()}
            style={{
              width: '100%', maxWidth: 480, margin: '0 auto',
              background: 'var(--card-bg)',
              borderTop: '1px solid rgba(0,212,255,0.3)',
              borderRadius: '24px 24px 0 0',
              padding: 24,
              animation: 'slide-up 0.25s ease',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
              <div>
                <p style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color: 'var(--electric-blue)', letterSpacing: 1 }}>
                  {selected.shopName}
                </p>
                <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 2 }}>{selected.name}</p>
              </div>
              <button onClick={() => setSelected(null)} style={{ background: 'rgba(255,255,255,0.05)', border: 'none', borderRadius: '50%', width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-secondary)' }}>
                <X size={16} />
              </button>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
              {[
                { label: 'Socket', value: `${selected.socketType} (${selected.powerKw}kW)` },
                { label: 'Price', value: `₹${selected.pricePerHour}/hour` },
                { label: 'Distance', value: `${selected.distanceKm} km away` },
                { label: 'Rating', value: `⭐ ${selected.rating} (${selected.totalCharges} charges)` },
              ].map(item => (
                <div key={item.label} style={{
                  background: 'rgba(0,212,255,0.05)',
                  border: '1px solid rgba(0,212,255,0.1)',
                  borderRadius: 10, padding: '10px 12px',
                }}>
                  <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>{item.label}</p>
                  <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', marginTop: 3 }}>{item.value}</p>
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16, padding: '10px 12px', background: 'rgba(0,212,255,0.04)', borderRadius: 10, border: '1px solid rgba(0,212,255,0.1)' }}>
              <MapPin size={14} color="var(--electric-blue)" />
              <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{selected.address}</span>
            </div>
            <button
              onClick={() => { onBook(selected); setSelected(null); }}
              disabled={!selected.isAvailable}
              style={{
                width: '100%',
                padding: '14px',
                borderRadius: 14,
                border: 'none',
                background: selected.isAvailable
                  ? 'linear-gradient(135deg, var(--electric-blue), var(--deep-blue))'
                  : 'rgba(255,69,96,0.2)',
                color: selected.isAvailable ? 'white' : 'var(--danger)',
                fontSize: 15,
                fontWeight: 600,
                cursor: selected.isAvailable ? 'pointer' : 'not-allowed',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                boxShadow: selected.isAvailable ? '0 4px 20px rgba(0,212,255,0.3)' : 'none',
              }}
            >
              <Clock size={16} />
              {selected.isAvailable ? 'Book a Charging Slot' : 'Currently Busy'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
