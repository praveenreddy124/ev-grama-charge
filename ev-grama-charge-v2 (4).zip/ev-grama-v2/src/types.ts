export interface Host {
  id: string;
  name: string;
  shopName: string;
  lat: number;
  lng: number;
  socketType: '5A' | '15A';
  pricePerHour: number;
  isAvailable: boolean;
  rating: number;
  totalCharges: number;
  distanceKm: number;
  address: string;
  phone: string;
  powerKw: number;
}

export type Tab = 'map' | 'booking' | 'calculator' | 'host';
